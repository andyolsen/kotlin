package inheritanceAndGenerics

open class A
open class B: A()
open class C: A()
